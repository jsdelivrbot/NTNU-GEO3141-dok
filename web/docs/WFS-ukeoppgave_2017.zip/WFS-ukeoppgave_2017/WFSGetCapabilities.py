#!/usr/bin/env python
# -*- coding: utf-8 -*-

# File: WFSGetcapabilities.py
# A script for sending a request to a WFS-server
# Author: Sverre Stikbakke
# Date: 2017.03.01

import codecs
import urllib
import urllib2
import xml.dom.minidom

input_file = "WFSGetCapabilities.xml"
output_file = "WFSGetCapabilitiesResponse.xml"
url = 'http://localhost:8080/geoserver/wfs'

print
print "url:        ", url
print "input file: ", input_file

try:
  print
  print "Composing the request"
  data = open(input_file, "r").read()
  req = urllib2.Request(url, data)
  req.add_header('Content-Type', 'text/xml')
  
  print "Sending request and receiving response"
  response = urllib2.urlopen(req)

  print "Parsing and saving the response"
  doc = xml.dom.minidom.parseString(response.read())
  pretty_doc = doc.toprettyxml(indent="  ", encoding = 'utf-8')

  the_file = open(output_file, "w")
  the_file.write(pretty_doc)
  the_file.close()

  print
  print pretty_doc[0:300]
  print
  print "See complete results in " + str(output_file)

except Exception as e:
  print
  print "======================================"
  print "Error - something went wrong - check:"
  print "======================================"
  print "- filenames"
  print "- is GeoServer running? - use Start GeoServer in Windows Start Menu"
  print 
  print "Otherwise - check this:"
  print
  print str(e)

print
raw_input("OK? - press enter")
