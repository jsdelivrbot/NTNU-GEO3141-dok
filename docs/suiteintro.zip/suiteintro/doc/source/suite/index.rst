.. _suite:

Part 1: OpenGeo Suite 
=====================

.. toctree::
   :maxdepth: 2

   introduction
   installation
   dashboard